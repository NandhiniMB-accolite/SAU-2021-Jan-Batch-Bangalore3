package com.testing.assign3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assign3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
