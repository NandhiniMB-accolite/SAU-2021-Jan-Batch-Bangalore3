package com.accolite.controller;

import com.accolite.model.Employee;
import org.junit.jupiter.api.*;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EmployeeControllerTest {

    EmployeeController employeeController;

    @BeforeAll
    public void beforeAllTest() {
        System.out.println("Welcome");
        // set something for an object
    }

    @BeforeEach
    public void beforeEachTest() {
        System.out.println("Before Each");
        this.employeeController = new EmployeeController();
    }

    @Test
    public void testAddEmployee() {
        System.out.println("Test case 1");
        Employee emp = new Employee("Saran", "VS", 21, 0);
        String fName = employeeController.addEmployee(emp);
        assertEquals("Saran",fName);
    }

    @Test
    public void testAddEmployee2() {
        System.out.println("Test case 2");
        Employee emp = mock(Employee.class);
        when(emp.getFirstName()).thenReturn("Rahul");
        String fName = employeeController.addEmployee(emp);
        assertEquals("Rahul",fName);
        verify(emp, times(1)).getFirstName();
    }

    @AfterEach
    public void afterEachTest() {
        System.out.println("After Each");
        this.employeeController = null;
    }

    @AfterAll
    public void afterAllTest() {
        System.out.println("Thanks");
    }
}