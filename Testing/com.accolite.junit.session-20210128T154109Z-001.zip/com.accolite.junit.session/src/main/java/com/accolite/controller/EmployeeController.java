package com.accolite.controller;

import com.accolite.model.Employee;

public class EmployeeController {
    public Employee employee;

    public String addEmployee(Employee employee) {
        this.employee = employee;
        return employee.getFirstName();   //"Rahul"
    }
}
