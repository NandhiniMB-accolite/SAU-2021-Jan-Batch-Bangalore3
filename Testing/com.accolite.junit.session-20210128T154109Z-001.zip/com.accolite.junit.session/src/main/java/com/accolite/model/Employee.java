package com.accolite.model;

public class Employee {
    public String firstName;
    public String lastName;
    public int age;
    public float salary;

    public Employee(String firstName, String lastName, int age, float salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.salary = salary;
    }

    public Employee() {
        this.firstName = "";
        this.lastName = "";
        this.age = 0;
        this.salary = 0;
    }

    public String getFirstName() {
        System.out.println("Hey");
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
}
